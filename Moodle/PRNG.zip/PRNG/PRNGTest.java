import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class PRNGTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class PRNGTest
{
    /**
     * Default constructor for test class PRNGTest
     */
    public PRNGTest() {
    }


    @Test
    public void testCorrectRange() {
        // pas de panique, il ne faut pas de statique ici

        for (int i = 0; i < 100; i++) {
            int res = PRNG.nextInt(10);
            //assert(res >= 0);
            //assert(res <= 10);
        }
        
    }
    

    
    // TODO: write more tests, par exemple tester que tous les nombres sont testes
}

