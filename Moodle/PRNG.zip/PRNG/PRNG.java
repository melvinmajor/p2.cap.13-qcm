 

import java.util.Random;

public final class PRNG {
    
    public static int seed = 0;
 
    public static void setSeed(int s) {
        seed = s;
    }
    
    /**
     * 
     * @return next random number: All 2^32 possible int values are produced with (approximately) equal probability.
     */
    public static int nextInt() {
        // TODO
        return 0;
    }

    /**
     * @param n > 0
     * @return next random number between 0 and n-1. All the values 0, ..., n-1 are produced with (approximately) equal probability.
     */
    public static int nextInt(int n) {
        // TODO
        return 0;
    }
}
